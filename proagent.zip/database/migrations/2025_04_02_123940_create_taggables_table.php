<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('taggables', function (Blueprint $table) {
            $table->increments('id');
   
			$table->morphs('taggable'); // Creates taggable_id and taggable_type columns
			$table->integer('tag_id')->nullable();
			$table->timestamps(); // Optional: if you need to track when tags were added 
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('taggables');
    }
};
