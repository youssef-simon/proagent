<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Application Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to display application language.
    | You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
	'your_experience_you_put_is_under_review'=>'المشروع الذى قمت بادخالة تحت المراجعة',
	'your_work_you_put_is_refused'=>'المشروع الذى قمت بادخالة تم رفضة',
	'your_work_you_put_is_accepted'=>'المشروع الذى قمت بادخالة تم قبولة',
	
	'your_service_you_put_is_under_review'=>'الخدمة التي أضفتها قيد المراجعة',
	'your_service_you_put_is_refused'=>' الخدمة التى اضفتها قد تم رقضها',
	'your_service_you_put_is_accepted'=>'الخدمة التي أضفتها  قد تم قبولها',
	'know_the_reason'=>' اعرف السبب',
	 
    ];
 
